#!/bin/bash
unset LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/tina/Documents/Teaching/JenaViromics2022/Programs/v94/runtime/glnxa64
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/tina/Documents/Teaching/JenaViromics2022/Programs/v94/bin/glnxa64
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/tina/Documents/Teaching/JenaViromics2022/Programs/v94/sys/os/glnxa64
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/tina/Documents/Teaching/JenaViromics2022/Programs/v94/extern/bin/glnxa64
